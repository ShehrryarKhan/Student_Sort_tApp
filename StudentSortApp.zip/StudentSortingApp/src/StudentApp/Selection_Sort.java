package StudentApp;

public class Selection_Sort {

    public static void sort(Student[] array, boolean ascending, boolean byName) {
        int n = array.length;
        for (int i = 0; i < n - 1; i++) {
            int extremeIndex = i;
            for (int j = i + 1; j < n; j++) {
                boolean condition;
                if (byName) {
                    condition = ascending ? array[j].getName().compareTo(array[extremeIndex].getName()) < 0 :
                                            array[j].getName().compareTo(array[extremeIndex].getName()) > 0;
                } else {
                    condition = ascending ? array[j].getId() < array[extremeIndex].getId() :
                                            array[j].getId() > array[extremeIndex].getId();
                }

                if (condition) {
                    extremeIndex = j;
                }
            }
            Student temp = array[extremeIndex];
            array[extremeIndex] = array[i];
            array[i] = temp;
        }
    }
}

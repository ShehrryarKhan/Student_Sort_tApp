package StudentApp;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StudentSortingApp {

    private static JTextField nameField;
    private static JTextField idField;
    private static JComboBox<String> sortByComboBox;
    private static JComboBox<String> sortOrderComboBox;
    private static JTable studentTable;
    private static DefaultTableModel tableModel;

    public static void main(String[] args) {
        
        JFrame frame = new JFrame("Student Records Management");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null); // Center the window on the screen

      
        JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        
        JLabel titleLabel = new JLabel("Student Records Management");
        titleLabel.setFont(new Font("Sans Serif", Font.BOLD, 20));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        mainPanel.add(titleLabel, gbc);

        
        JLabel nameLabel = new JLabel("Name:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        mainPanel.add(nameLabel, gbc);

        nameField = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        mainPanel.add(nameField, gbc);

        JLabel idLabel = new JLabel("ID:");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        mainPanel.add(idLabel, gbc);

        idField = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        mainPanel.add(idField, gbc);

        // Sorting options
        JLabel sortByLabel = new JLabel("Sort By:");
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        mainPanel.add(sortByLabel, gbc);

        sortByComboBox = new JComboBox<>(new String[]{"Name", "ID"});
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        mainPanel.add(sortByComboBox, gbc);

        JLabel sortOrderLabel = new JLabel("Sort Order:");
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        mainPanel.add(sortOrderLabel, gbc);

        sortOrderComboBox = new JComboBox<>(new String[]{"Ascending", "Descending"});
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        mainPanel.add(sortOrderComboBox, gbc);

        // Buttons
        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add Record");
        addButton.setBackground(new Color(34, 139, 34)); // Forest Green
        addButton.setForeground(Color.WHITE);
        addButton.setFocusPainted(false);
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addRecord();
            }
        });
        buttonPanel.add(addButton);

        JButton sortButton = new JButton("Sort");
        sortButton.setBackground(new Color(30, 144, 255)); // Dodger Blue
        sortButton.setForeground(Color.WHITE);
        sortButton.setFocusPainted(false);
        sortButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sortRecords();
            }
        });
        buttonPanel.add(sortButton);

        JButton clearButton = new JButton("Clear");
        clearButton.setBackground(new Color(255, 69, 58)); // Red
        clearButton.setForeground(Color.WHITE);
        clearButton.setFocusPainted(false);
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearRecords();
            }
        });
        buttonPanel.add(clearButton);

        JButton exitButton = new JButton("Exit");
        exitButton.setBackground(new Color(70, 130, 180)); // Steel Blue
        exitButton.setForeground(Color.WHITE);
        exitButton.setFocusPainted(false);
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        buttonPanel.add(exitButton);

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 3;
        mainPanel.add(buttonPanel, gbc);

       
        String[] columnNames = {"Name", "ID"};
        tableModel = new DefaultTableModel(columnNames, 0);
        studentTable = new JTable(tableModel);
        JScrollPane tableScrollPane = new JScrollPane(studentTable);
        tableScrollPane.setBorder(BorderFactory.createTitledBorder("Student Records"));

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        mainPanel.add(tableScrollPane, gbc);

        
        frame.setContentPane(mainPanel);
        frame.setVisible(true);
    }

    private static void addRecord() {
        try {
            String name = nameField.getText().trim();
            int id = Integer.parseInt(idField.getText().trim());

            if (name.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Name cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            
            tableModel.addRow(new Object[]{name, id});
            nameField.setText("");
            idField.setText("");

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid ID. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void sortRecords() {
        int rowCount = tableModel.getRowCount();
        Student[] students = new Student[rowCount];

        // Create an array of Student objects from the table data
        for (int i = 0; i < rowCount; i++) {
            String name = (String) tableModel.getValueAt(i, 0);
            int id = (int) tableModel.getValueAt(i, 1);
            students[i] = new Student(name, id);
        }

       
        boolean ascending = "Ascending".equals(sortOrderComboBox.getSelectedItem());
        boolean byName = "Name".equals(sortByComboBox.getSelectedItem());

       
        Selection_Sort.sort(students, ascending, byName);

       
        tableModel.setRowCount(0);

        
        for (Student student : students) {
            tableModel.addRow(new Object[]{student.getName(), student.getId()});
        }
    }

    private static void clearRecords() {
        tableModel.setRowCount(0);
        nameField.setText("");
        idField.setText("");
    }
}
